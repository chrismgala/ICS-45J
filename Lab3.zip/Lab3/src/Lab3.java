// Lab3.java (Main)
// Constructs a new MovieManager object. Call run() on it and let the program run.

// Chris Gala 64338761
// Wai Phyo 60902242

public class Lab3
{
	// Main method of the program. It simply makes a new MovieManager and runs the program.
	public static void main(String[] args) 
	{
		MovieManager mm = new MovieManager();
		mm.run();
	}
}
