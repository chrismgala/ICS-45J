// Lab2.java (Main)
// Creates a new simulation and starts it.

// Chris Gala 64338761
// Wai Phyo 60902242

public class Lab2
{
	public static void main(String[] args) 
	{
		CrapsSimulation cs = new CrapsSimulation();
		cs.start();
	}
}
